<?php
/** 
 * A WordPress fő konfigurációs állománya
 *
 * Ebben a fájlban a következő beállításokat lehet megtenni: MySQL beállítások
 * tábla előtagok, titkos kulcsok, a WordPress nyelve, és ABSPATH.
 * További információ a fájl lehetséges opcióiról angolul itt található:
 * {@link http://codex.wordpress.org/Editing_wp-config.php Editing wp-config.php} 
 *  A MySQL beállításokat a szolgáltatónktól kell kérni.
 *
 * Ebből a fájlból készül el a telepítési folyamat közben a wp-config.php
 * állomány. Nem kötelező a webes telepítés használata, elegendő átnevezni 
 * "wp-config.php" névre, és kitölteni az értékeket.
 *
 * @package WordPress
 */

// ** MySQL beállítások - Ezeket a szolgálatótól lehet beszerezni ** //
/** Adatbázis neve */
define('DB_NAME', '');

/** MySQL felhasználónév */
define('DB_USER', '');

/** MySQL jelszó. */
define('DB_PASSWORD', '');

/** MySQL  kiszolgáló neve */
define('DB_HOST', 'localhost');

/** Az adatbázis karakter kódolása */
define('DB_CHARSET', 'utf8mb4');

/** Az adatbázis egybevetése */
define('DB_COLLATE', '');

/**#@+
 * Bejelentkezést tikosító kulcsok
 *
 * Változtassuk meg a lenti konstansok értékét egy-egy tetszóleges mondatra.
 * Generálhatunk is ilyen kulcsokat a {@link http://api.wordpress.org/secret-key/1.1/ WordPress.org titkos kulcs szolgáltatásával}
 * Ezeknek a kulcsoknak a módosításával bármikor kiléptethető az összes bejelentkezett felhasználó az oldalról. 
 *
 * @since 2.6.0
 */
define('AUTH_KEY', 's0mWa+3Lu8/rMywP]o_hl)S2owO_o.OXlR!}~1zpR @l2?PGi|:,6}3lu4O[/X<>');
define('SECURE_AUTH_KEY', 'NF! f5B&sk]5YQ9z#{nLwU4(0J5jF[&.3TCrK8>O[<3=J2zO^R3!?rRjavVrCJ J');
define('LOGGED_IN_KEY', 'TI|!z5D)W]VHDH>xgx~~.&!{o=P)WJ%{Wfr}h5scom.jcqk1)EEjLEv@~=%b_e.V');
define('NONCE_KEY', '#z/9#N:=Z#wxsK:FyrnK7X/py;N3<Y]K)#powO,F=gq|w9OS>)8f}]|iyvdrp+.o');
define('AUTH_SALT',        'O<Ig-%hsBTyvNLXzH0L=??@R&EfSp;Ml6j]$oz[oF(!=A(ENJU002N58;q#NbnM)');
define('SECURE_AUTH_SALT', 'YmXp>>p0h!-bw1AAf(n{cz`ezCO}dIXbN{EUZ=XshMYg^ex,Fx#[58evk;{sEqB<');
define('LOGGED_IN_SALT',   '!<<Ne):-.Hd]G1-4><daUqKk diR4?Xs*0e,h1f#-i#.a49Q=M@=lozfk%&|ij/5');
define('NONCE_SALT',       'eSpc;5AaW%}$YEtp{PBt59-?uYWbc=@U:@cn!0:LxmDnc+f!i`z]QD1t&:H[0#=e');

/**#@-*/

/**
 * WordPress-adatbázis tábla előtag.
 *
 * Több blogot is telepíthetünk egy adatbázisba, ha valamennyinek egyedi
 * előtagot adunk. Csak számokat, betűket és alulvonásokat adhatunk meg.
 */
$table_prefix  = 'demo1wp_';

/**
 * Fejlesztőknek: WordPress hibakereső mód.
 *
 * Engedélyezzük ezt a megjegyzések megjelenítéséhez a fejlesztés során. 
 * Erősen ajánlott, hogy a bővítmény- és sablonfejlesztők használják a WP_DEBUG
 * konstansot.
 */
define('WP_DEBUG', false);

/* Ennyi volt, kellemes blogolást! */

/** A WordPress könyvtár abszolút elérési útja. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Betöltjük a WordPress változókat és szükséges fájlokat. */
require_once(ABSPATH . 'wp-settings.php');
